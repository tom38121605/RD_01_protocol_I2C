
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "nrf_drv_twi.h"

#include "mpu9250_register_map.h"
#include "nrf_mpu9250_twi_drv.h"

#include "app_util_platform.h"
#include "nrf_gpio.h"
#include "nrf_drv_config.h"
#include "nrf_delay.h"


//TWI���Ŷ���
#define MPU_TWI_SCL_PIN 22
#define MPU_TWI_SDA_PIN 23



#define MPU_TWI_BUFFER_SIZE     	  14 



static const nrf_drv_twi_t m_twi_instance = NRF_DRV_TWI_INSTANCE(0);
volatile static bool twi_tx_done = false;
volatile static bool twi_rx_done = false;

uint8_t twi_tx_buffer[MPU_TWI_BUFFER_SIZE];

static void nrf_drv_mpu_twi_event_handler(nrf_drv_twi_evt_t const * p_event, void * p_context)
{
    switch(p_event->type)
    {
        case NRF_DRV_TWI_EVT_DONE:
            switch(p_event->xfer_desc.type)
            {
                case NRF_DRV_TWI_XFER_TX:
                    twi_tx_done = true;
                    break;
                case NRF_DRV_TWI_XFER_TXTX:
                    twi_tx_done = true;
                    break;
                case NRF_DRV_TWI_XFER_RX:
                    twi_rx_done = true;
                    break;
                case NRF_DRV_TWI_XFER_TXRX:
                    twi_rx_done = true;
                    break;
                default:
                    break;
            }
            break;
        case NRF_DRV_TWI_EVT_ADDRESS_NACK:
            break;
        case NRF_DRV_TWI_EVT_DATA_NACK:
            break;
        default:
            break;
    }
}

/**********************************************************************************************
 * ��  �� : mpu9250_twi_init()
 * ��  �� : ��
 * ����ֵ : 
 ***********************************************************************************************/
static uint32_t mpu9250_twi_init(void)
{
    uint32_t err_code;
    
    const nrf_drv_twi_config_t twi_mpu_config = {
       .scl                = MPU_TWI_SCL_PIN,
       .sda                = MPU_TWI_SDA_PIN,
       .frequency          = NRF_TWI_FREQ_400K,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGHEST
    };
    
    err_code = nrf_drv_twi_init(&m_twi_instance, &twi_mpu_config, nrf_drv_mpu_twi_event_handler, NULL);
    if(err_code != NRF_SUCCESS)
	  {
		    return err_code;
	  }
    
    nrf_drv_twi_enable(&m_twi_instance);
	
	  return NRF_SUCCESS;
}

// The TWI driver is not able to do two transmits without repeating the ADDRESS + Write bit byte
// Hence we need to merge the MPU register address with the buffer and then transmit all as one transmission
static void merge_register_and_data(uint8_t * new_buffer, uint8_t reg, uint8_t * p_data, uint32_t length)
{
    new_buffer[0] = reg;
    memcpy((new_buffer + 1), p_data, length);
}

uint32_t nrf_drv_mpu_write_registers(uint8_t reg, uint8_t * p_data, uint32_t length)
{
    // This burst write function is not optimal and needs improvement.
    // The new SDK 11 TWI driver is not able to do two transmits without repeating the ADDRESS + Write bit byte
    uint32_t err_code;
    uint32_t timeout = MPU9250_TWI_TIMEOUT;

    // Merging MPU register address and p_data into one buffer.
    merge_register_and_data(twi_tx_buffer, reg, p_data, length);

    // Setting up transfer
    nrf_drv_twi_xfer_desc_t xfer_desc;
    xfer_desc.address = MPU9250_ADDRESS;
    xfer_desc.type = NRF_DRV_TWI_XFER_TX;
    xfer_desc.primary_length = length + 1;
    xfer_desc.p_primary_buf = twi_tx_buffer;

    // Transferring
    err_code = nrf_drv_twi_xfer(&m_twi_instance, &xfer_desc, 0);

    while((!twi_tx_done) && --timeout);
    if(!timeout) return NRF_ERROR_TIMEOUT;
    twi_tx_done = false;

    return err_code;
}
uint32_t nrf_drv_mpu_write_single_register(uint8_t reg, uint8_t data)
{
    uint32_t err_code;
    uint32_t timeout = MPU9250_TWI_TIMEOUT;

    uint8_t packet[2] = {reg, data};

    err_code = nrf_drv_twi_tx(&m_twi_instance, MPU9250_ADDRESS, packet, 2, false);
    if(err_code != NRF_SUCCESS) return err_code;

    while((!twi_tx_done) && --timeout);
    if(!timeout) return NRF_ERROR_TIMEOUT;

    twi_tx_done = false;

    return err_code;
}


uint32_t nrf_drv_mpu_read_registers(uint8_t reg, uint8_t * p_data, uint32_t length)
{
    uint32_t err_code;
    uint32_t timeout = MPU9250_TWI_TIMEOUT;

    err_code = nrf_drv_twi_tx(&m_twi_instance, MPU9250_ADDRESS, &reg, 1, false);
    if(err_code != NRF_SUCCESS) return err_code;

    while((!twi_tx_done) && --timeout);
    if(!timeout) return NRF_ERROR_TIMEOUT;
    twi_tx_done = false;

    err_code = nrf_drv_twi_rx(&m_twi_instance, MPU9250_ADDRESS, p_data, length);
    if(err_code != NRF_SUCCESS) return err_code;

    timeout = MPU9250_TWI_TIMEOUT;
    while((!twi_rx_done) && --timeout);
    if(!timeout) return NRF_ERROR_TIMEOUT;
    twi_rx_done = false;

    return err_code;
}
uint32_t nrf_drv_mpu_read_magnetometer_registers(uint8_t reg, uint8_t * p_data, uint32_t length)
{
    uint32_t err_code;
    uint32_t timeout = MPU9250_TWI_TIMEOUT;

    err_code = nrf_drv_twi_tx(&m_twi_instance, AK8963_MAGN_ADDRESS, &reg, 1, false);
    if(err_code != NRF_SUCCESS) return err_code;

    while((!twi_tx_done) && --timeout);
    if(!timeout) return NRF_ERROR_TIMEOUT;
    twi_tx_done = false;

    err_code = nrf_drv_twi_rx(&m_twi_instance, AK8963_MAGN_ADDRESS, p_data, length);
    if(err_code != NRF_SUCCESS) return err_code;

    timeout = MPU9250_TWI_TIMEOUT;
    while((!twi_rx_done) && --timeout);
    if(!timeout) return NRF_ERROR_TIMEOUT;
    twi_rx_done = false;

    return err_code;
}
uint32_t nrf_drv_mpu_write_magnetometer_register(uint8_t reg, uint8_t data)
{
    uint32_t err_code;
    uint32_t timeout = MPU9250_TWI_TIMEOUT;

    uint8_t packet[2] = {reg, data};

    err_code = nrf_drv_twi_tx(&m_twi_instance, AK8963_MAGN_ADDRESS, packet, 2, false);
    if(err_code != NRF_SUCCESS) return err_code;

    while((!twi_tx_done) && --timeout);
    if(!timeout) return NRF_ERROR_TIMEOUT;

    twi_tx_done = false;

    return err_code;
}
/**********************************************************************************************
 * ��  �� : ��ȡ���ٶȼ�����
 * ��  �� : ��
 * ����ֵ : ��
 **********************************************************************************************/
uint32_t mpu9250_read_accel(accel_values_t * accel_values)
{
    uint32_t err_code;
    uint8_t raw_values[6];
    err_code = nrf_drv_mpu_read_registers(MPU9250_REG_ACCEL_XOUT_H, raw_values, 6);
    if(err_code != NRF_SUCCESS) return err_code;
			
		// Reorganize read sensor values and put them into value struct
    uint8_t *data;
    data = (uint8_t*)accel_values;
    for(uint8_t i = 0; i<6; i++)
    {
        *data = raw_values[5-i];
        data++;
    }
    return NRF_SUCCESS;
}
/**********************************************************************************************
 * ��  �� : ��ȡ����������
 * ��  �� : ��
 * ����ֵ : ��
 **********************************************************************************************/
uint32_t mpu9250_read_gyro(gyro_values_t * gyro_values)
{
    uint32_t err_code;
    uint8_t raw_values[6];
    err_code = nrf_drv_mpu_read_registers(MPU9250_REG_GYRO_XOUT_H, raw_values, 6);
    if(err_code != NRF_SUCCESS) return err_code;

    uint8_t *data;
    data = (uint8_t*)gyro_values;
    for(uint8_t i = 0; i<6; i++)
    {
        *data = raw_values[5-i];
        data++;
    }
    return NRF_SUCCESS;
}
/**********************************************************************************************
 * ��  �� : ��ȡ����������
 * ��  �� : ��
 * ����ֵ : ��
 **********************************************************************************************/
uint32_t mpu9250_read_mag(mag_values_t * mag_values)
{
	  uint32_t err_code;

    err_code = nrf_drv_mpu_read_magnetometer_registers(MPU9250_REG_AK8963_XOUT_L, (uint8_t *)mag_values, 6);
    if(err_code != NRF_SUCCESS) return err_code;
    
		nrf_drv_mpu_write_magnetometer_register(MPU9250_REG_AK8963_CNTL,0x11); //AK8963ÿ�ζ����Ժ���Ҫ��������Ϊ���β���ģʽ���������ݲ������
    return NRF_SUCCESS;
}

uint32_t mpu9250_read_temp(temp_value_t * temperature)
{
    uint32_t err_code;
    uint8_t raw_values[2];
    err_code = nrf_drv_mpu_read_registers(MPU9250_REG_TEMP_OUT_H, raw_values, 2);
    if(err_code != NRF_SUCCESS) return err_code;  
    
    *temperature = (temp_value_t)(raw_values[0] << 8) + raw_values[1];
    
    return NRF_SUCCESS;    
}

void mpu9250_ad0_config(bool set)
{
	  if(set == true)nrf_gpio_pin_set(MPU9250_AD0_PIN);
	  else nrf_gpio_pin_clear(MPU9250_AD0_PIN);
}
uint32_t mpu9250_config(mpu_config_t * config)
{
    uint8_t *data;
    data = (uint8_t*)config;
    return nrf_drv_mpu_write_registers(MPU9250_REG_SMPLRT_DIV, data, 4);
}
uint32_t mpu_int_cfg_pin(mpu_int_pin_cfg_t *cfg)
{
    uint8_t *data;
    data = (uint8_t*)cfg;
    return nrf_drv_mpu_write_single_register(MPU9250_REG_INT_PIN_CFG, *data);
    
}
uint32_t mpu_magnetometer_init(mpu_magn_config_t * p_magnetometer_conf)
{	
	  uint32_t err_code;
	
	  //�ȶ���INT Pin / Bypass �Ĵ�����ֵ
	  mpu_int_pin_cfg_t bypass_config;
	  err_code = nrf_drv_mpu_read_registers(MPU9250_REG_INT_PIN_CFG, (uint8_t *)&bypass_config, 1);
	
	  //�޸�bypass_enλΪ1
	  bypass_config.i2c_bypass_en = 1;
	  //�޸ĺ���д��INT Pin / Bypass �Ĵ���	
	  err_code = mpu_int_cfg_pin(&bypass_config);
	  if (err_code != NRF_SUCCESS) return err_code;
	
	  //дINT Pin / Bypass 	
	  uint8_t *data;
    data = (uint8_t*)p_magnetometer_conf;	
    return nrf_drv_mpu_write_magnetometer_register(MPU9250_REG_AK8963_CNTL, *data);
}



uint32_t mpu9250_init(void)
{
    uint32_t err_code;
	  uint8_t id =0;
	
	  //����mpu9250 i2c��ַAD0λΪ1
	  nrf_gpio_cfg_output(MPU9250_AD0_PIN);
	  mpu9250_ad0_config(false);
	
	  //��ʼ��TWI
	  err_code = mpu9250_twi_init();
    if(err_code != NRF_SUCCESS) return err_code;
	
    //��ȡMPU9250����ID(WHO_AM_I�Ĵ���ֵ)��������ֵӦ��0x71
	  do
	  {
		    nrf_drv_mpu_read_registers(MPU9250_REG_WHO_AM_I,&id,1);
			  if(id != MPU9250_WHO_AM_I_VALUE)
				{
					  printf("ID:  %d\r\n",id);
			      printf("mpu9250 init err...\r\n");
			      nrf_delay_ms(500);
				}
		}while(id != MPU9250_WHO_AM_I_VALUE);

	  //��λgyro, accelerometer temperature sensor
	  uint8_t reset_value = 7; 
    err_code = nrf_drv_mpu_write_single_register(MPU9250_REG_SIGNAL_PATH_RESET, reset_value);
    if(err_code != NRF_SUCCESS) return err_code;

    //ʹ���ڲ�20MHz����
    err_code = nrf_drv_mpu_write_single_register(MPU9250_REG_PWR_MGMT_1, 0x00);
    if(err_code != NRF_SUCCESS) return err_code;
		
		//����mpu9250
    mpu_config_t p_mpu_config = MPU_DEFAULT_CONFIG(); //����Ĭ��ֵ
    p_mpu_config.smplrt_div = 7;   //���ò������ʡ��������� = Internal_Sample_Rate / (1 + SMPLRT_DIV)�� 19��Ӧ����50Hz
    p_mpu_config.accel_config.afs_sel = AFS_2G; //���ü��ٶȼ�������2G
    
	  err_code = mpu9250_config(&p_mpu_config); 
    APP_ERROR_CHECK(err_code); 
    
	
	  // Enable magnetometer
	  mpu_magn_config_t magnetometer_config;
	  magnetometer_config.mode = SINGLE_MEASUREMENT_MODE;
	  magnetometer_config.resolution = 1;
    err_code = mpu_magnetometer_init(&magnetometer_config);
    APP_ERROR_CHECK(err_code); 

    return NRF_SUCCESS;
}









