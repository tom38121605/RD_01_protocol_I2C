
#include <stdbool.h>
#include <stdint.h>
#include "nrf_gpio.h"
#include "nrf_drv_twi.h"
#include "mpu9250_register_map.h"
#include "nrf_mpu9250_twi_drv.h"
#include "app_mpu9250.h"
#include "app_uart.h"
#include "nrf_delay.h"












